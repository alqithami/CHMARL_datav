#!/usr/bin/env bash
set -euo pipefail

ROOT="${1:-.}"
cd "$ROOT"

cp server/vessel-feed-proxy/index.mjs "server/vessel-feed-proxy/index.mjs.backup.$(date +%Y%m%d-%H%M%S)" 2>/dev/null || true
cp "$(dirname "$0")/server/vessel-feed-proxy/index.mjs" server/vessel-feed-proxy/index.mjs
mkdir -p public/data scripts docs
cp "$(dirname "$0")/public/data/manual_vessels.sample.json" public/data/manual_vessels.sample.json
cp "$(dirname "$0")/scripts/ingest-fixed-vessels.mjs" scripts/ingest-fixed-vessels.mjs
cp "$(dirname "$0")/docs/ECOFAIR_INPUTS.md" docs/ECOFAIR_INPUTS.md
chmod +x scripts/ingest-fixed-vessels.mjs

python - <<'PY'
import json
from pathlib import Path

# package.json script
pkg = Path('package.json')
data = json.loads(pkg.read_text())
scripts = data.setdefault('scripts', {})
scripts.setdefault('ingest:fixed-vessels', 'node scripts/ingest-fixed-vessels.mjs')
pkg.write_text(json.dumps(data, indent=2) + '\n')

# .env.example additions
example = Path('.env.example')
text = example.read_text() if example.exists() else ''
insert = '''
# Fixed/manual vessel rows merged into EcoFair-CH-MARL input.
# Use this when AISStream is sparse for Saudi ports or to provide known baselines.
FIXED_VESSEL_DATA_FILE=.runtime/manual_vessels.json
FIXED_VESSEL_DATA_FILE_ENABLED=true
FIXED_VESSEL_DATA_URL=
FIXED_VESSEL_DATA_TOKEN=
# Optional bearer token for POST /api/vessels/ingest.
FIXED_VESSEL_INGEST_TOKEN=
'''
if 'FIXED_VESSEL_DATA_FILE=' not in text:
    marker = '# Runtime CH-MARL experiment feed and ingestion endpoint.'
    text = text.replace(marker, insert + '\n' + marker) if marker in text else text + insert
example.write_text(text)

# docs index append
measures = Path('docs/ECOFAIR_MEASURES.md')
if measures.exists():
    m = measures.read_text()
    if 'Fixed/manual vessel input' not in m:
        m += '''

## Fixed/manual vessel input

The runtime can merge live AISStream rows, upstream API rows, and fixed/manual vessel rows. Fixed rows are loaded from `FIXED_VESSEL_DATA_FILE` and can also be written through `POST /api/vessels/ingest`. This is used for known Saudi vessels or test baselines when AISStream does not deliver regional rows.
'''
        measures.write_text(m)
PY

pnpm install
pnpm build

echo "EcoFair input integration applied. Review with: git status --short"
